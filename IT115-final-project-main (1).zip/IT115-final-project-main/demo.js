function changeMsg() {
    var input = document.theForm.elements[0].value;
    document.getElementById("msg").innerHTML = input;
    //document.getElementById("msg").innerHTML = "test";
    //return input;
}
